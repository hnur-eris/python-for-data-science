from ft_package import magic

def main():
    magic()
    

if __name__ == "__main__":
    main()