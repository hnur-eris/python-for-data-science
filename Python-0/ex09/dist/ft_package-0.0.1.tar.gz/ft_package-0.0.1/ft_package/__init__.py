from .example import magic

