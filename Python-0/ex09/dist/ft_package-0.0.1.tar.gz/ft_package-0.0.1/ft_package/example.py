def magic():
    print("Harry Potter killed Voldermore with his staff")
