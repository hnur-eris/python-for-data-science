I learn to create a package this website;
https://packaging.python.org/en/latest/tutorials/packaging-projects/

